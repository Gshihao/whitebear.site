# This is  the Document the explain
# 2023-4-20 11：00

js/Mouseonclick.js 鼠标点击效果